# Dadata website

A responsive, company-only single-page website built with Next.js, TypeScript, and Tailwind CSS. No personal contact details, form, analytics, cookies, or external fonts are included. LinkedIn is the contact channel.

## Local development
Requires Node.js 22 and npm.

```sh
npm install
npm run dev
npm run typecheck
npm run build
```

The production export is written to `out/`. The default path is `/dadata-website`. Local development therefore uses `http://localhost:3000/dadata-website/`.

## Content editing
Edit `app/content.ts` for services, solutions, and approach. Edit `app/page.tsx` for headings and company copy. Styles are in `app/globals.css`.

## Publication requires separate approval
The workflow is manual-only. Committing this package does not trigger deployment.
1. Review content and approve publication.
2. In repository Settings > Pages > Build and deployment, select GitHub Actions.
3. Open Actions > Deploy Dadata to GitHub Pages > Run workflow and select the main branch.
4. Inspect build and deployment logs. The environment output gives the published address.

The intended initial address is https://dadata108.github.io/dadata-website/ . This is not a claim that the site is live.

## Dependency lockfile
No npm runtime was available during preparation. Run `npm install`, review and commit the generated `package-lock.json`, then change the workflow install command to `npm ci` for reproducible installations. Do not claim a successful build until the workflow or local build succeeds.

## Custom domain
No CNAME is included. After domain approval, configure the domain in Pages and DNS; change `NEXT_PUBLIC_BASE_PATH` to an empty string in the workflow and rebuild. Review canonical URLs and sitemap at that time. This draft omits canonical URLs and a sitemap rather than guessing the production domain.

## Validation status
Preparation checked file presence, JSON syntax, relative source imports, and absence of supplied personal details. npm installation, TypeScript, browser tests, accessibility audits, and production build have NOT run. GitHub Actions performs the first executable build. Action major versions and package versions should be reviewed at release time.

## Scope
The simplified prompt is implemented as one landing page with anchored sections: Home, Services, Solutions, About, Contact. There are no runtime APIs or backend dependencies.
