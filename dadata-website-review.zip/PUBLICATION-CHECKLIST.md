# Publication checklist

- [ ] Approve company copy and service capabilities.
- [ ] Verify company LinkedIn destination.
- [ ] Confirm no personal information appears in public site content.
- [ ] Confirm repository visibility and acceptable public source exposure.
- [ ] Review package and Actions versions; generate and commit lockfile.
- [ ] Run typecheck and production build; resolve errors.
- [ ] Test mobile layout, keyboard navigation, contrast, and contact links.
- [ ] Confirm base path and all exported assets.
- [ ] Approve publication separately from committing code.
- [ ] Enable Pages source: GitHub Actions.
- [ ] Manually run deployment; verify successful logs and published URL.
- [ ] Test live site before custom-domain work.

No client testimonials, metrics, personal credentials, personal contact information, tracking, or client logos are included.
