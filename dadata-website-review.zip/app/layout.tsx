import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
 title: 'Dadata | Data Governance, Databricks & Collibra',
 description: 'Dadata connects enterprise data governance with hands-on Databricks, Collibra, integration, lineage, and data quality expertise.',
 openGraph: { title: 'Dadata | Trusted Data. Governed Platforms.', description: 'Governance strategy connected with practical engineering.', type: 'website' }
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
 return <html lang="en"><body>{children}</body></html>;
}
