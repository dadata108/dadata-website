export default function NotFound(){return <main style={{padding:60,fontFamily:'Arial'}}><h1>Page not found</h1><p>Use your browser’s back button to return to Dadata.</p></main>}
