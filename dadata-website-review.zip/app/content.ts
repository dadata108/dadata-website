export const linkedin = 'https://www.linkedin.com/company/dadataco/';
export const services = [
 { title: 'Databricks & Unity Catalog', text: 'Build governed lakehouse foundations with Delta Lake, PySpark, SQL, batch and streaming pipelines, access controls, and deployment automation.', tags: 'Databricks · Delta Lake · Unity Catalog' },
 { title: 'Collibra & Data Governance', text: 'Connect business glossaries, catalogs, ownership, and stewardship with practical operating models, Collibra Edge integrations, and custom workflows.', tags: 'Collibra · Java · Groovy · REST APIs' },
 { title: 'Lineage & Data Quality', text: 'Connect source-to-report traceability, impact analysis, quality rules, dashboards, and issue remediation so teams can investigate data with context.', tags: 'Manta · Collibra DQ · Airflow' },
 { title: 'Enterprise Integration', text: 'Connect metadata and operational processes across cloud platforms, databases, SAP, Salesforce, and ServiceNow with maintainable APIs and integrations.', tags: 'MuleSoft · Spring Boot · Python' },
 { title: 'Governed AI & Document Intelligence', text: 'Turn unstructured documents into validated metadata through extraction pipelines, traceability controls, and trusted data foundations for analytics and AI.', tags: 'Document processing · Validation · MLflow' }
];
export const solutions = [
 ['Connect platform and enterprise governance', 'Align Unity Catalog technical metadata with business terms, owners, and stewardship in Collibra.'],
 ['Understand source-to-report dependencies', 'Link technical and business lineage to support investigation and change impact analysis.'],
 ['Operationalize data quality', 'Connect rules, quality signals, accountable owners, and remediation workflows.'],
 ['Simplify governed data access', 'Coordinate requests, approvals, and provisioning through integrated workflows.'],
 ['Structure contract metadata', 'Combine document ingestion, extraction, validation, and downstream publication.'],
 ['Establish shared business meaning', 'Create glossary, KPI, and critical data element definitions with clear ownership.']
];
export const approach = [
 ['Assess', 'Understand priorities, platform constraints, and governance gaps.'],
 ['Design', 'Define the operating model, architecture, and implementation roadmap.'],
 ['Implement', 'Build integrations, workflows, pipelines, and controls.'],
 ['Enable', 'Validate delivery, document decisions, and equip teams for adoption.']
];
